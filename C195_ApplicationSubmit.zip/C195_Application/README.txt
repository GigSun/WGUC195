•  Title: C195 Software II In Java 
•  Purpose: Create GUI-based scheduling desktop application to pull data from MySQL database and manage cusomters and appointments record based on oranization's specific business requirements
•  Author :Wei Sun Zhang,Email: wzhan10@wgu.edu. 

•  Application Information:
   IDE :IntelliJ Community Edition 2020.03), full 
   JDK of version 15 used ,Open JDK-15 Version 15.0.2
   JavaFX version compatible with JDK 15 (JavaFX-SDK-15.0.2)

•  Directions for how to run the program: Run Main method and login to application MainScreen by pressing "Login" button. From the MainScreen view , User can choose button to view and manage Customers, Appointments and Reports.   

•  Report 3: View numbers of appointments by 3 contacts by month. 

•  MySQL Connector driver version number: mysql-connector-java-8.0.23