package Model;

/** User class. */
    public class User {

    private String username;
    private int userID;


    /**  Constructor
     *
     */
    public User() { }

    /** Constructor
     *
     * @param userID userID
     * @param username userName
     */
    public User(int userID,String username){
        setUsername(username);
        setUserID(userID);
    }

    /** Set method for user ID
     *
     * @param userID userID
     */

    public void setUserID(int userID) {

        this.userID = userID;
    }

    /**Get method to return userID
     *
     * @return userID
     */
    public int getUserID() {

        return userID;
    }

    /**Get method to get userName
     *
     * @return userName
     */
    public String getUsername(){

        return  username;
    }

    /**Set method to set userName
     *
     * @param username userName
     */
    public void setUsername(String username){

        this.username = username;
    }




}
