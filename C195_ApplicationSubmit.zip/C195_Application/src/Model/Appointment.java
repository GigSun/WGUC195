package Model;



/**  the appointment Class defines methods and attributes for Appointment.*/

public class Appointment {

    private  int  appointmentID;
    private  int  customerID;
    private  int  userID;
    private  String appointmentStart;
    private  String appointmentEnd;
    private  String appointmentTitle;
    private  String appointmentType;
    private  String appointmentLocation;
    private  String appointmentContact;
    private  String appointmentDescription;
    private  String createdBy;
    private  String createdD;


    /**
     * Default constructor
     */
    public Appointment(){}

    /**Constructor with appointmentContact attribute used in  AppointmentDB. getAllAppointment  method
     *
     * @param appointmentID return appID.
     * @param appointmentTitle  title
     * @param appointmentLocation  location
     * @param appointmentDescription description
     * @param appointmentContact  contact
     * @param type   type
     * @param appointmentStart  start Time
     * @param appointmentEnd   end Time
     * @param customerID    customer id
     * @param userId      user id
     * @param createdBy   created by
     * @param createdD    created time
     */

    public Appointment(int appointmentID ,String appointmentTitle,String appointmentLocation, String appointmentDescription, String appointmentContact ,String type,String appointmentStart, String appointmentEnd,int customerID,int userId, String createdBy,String createdD){
        setAppointmentID(appointmentID);
        setAppointmentCustomerID(customerID);
        setAppointmentUserID(userId);
        setAppointmentStart(appointmentStart);
        setAppointmentEnd(appointmentEnd);
        setAppointmentTitle(appointmentTitle);
        setAppointmentLocation(appointmentLocation);
        setAppointmentType(type);
        setAppointmentDescription(appointmentDescription);
        setAppointmentContact( appointmentContact);
        setCreatedBy(createdBy);
        setCreateDate(createdD);

    }




    /** Set method for createdBy  , update the name for appointment instance
     *
     * @param createdBy created user
     */

    private void setCreatedBy(String createdBy) {
        this.createdBy= createdBy; }


    /**Set method for appointment type  , update the type for appointment instance
     *
      * @param appointmentType type
     */

    public void setAppointmentType(String appointmentType) {

        this.appointmentType = appointmentType;
    }


    /**Set method for title  , update the title for appointment instance
     *
     * @param appointmentTitle title
     */
    public void setAppointmentTitle(String appointmentTitle) {

        this.appointmentTitle = appointmentTitle;
    }

    /**Set method for userID  , update the userID for appointment instance
     *
     * @param userID id
     */
    public void setAppointmentUserID(int userID) {

        this.userID = userID;
    }

    /**Set method for customerID  , update the customerID for appointment instance
     *
     * @param customerID  customerID
     */
    public void setAppointmentCustomerID(int customerID){

        this.customerID=customerID;
    }


    /**Set method for appointmentID  , update the appointmentID  for appointment instance
     *
     * @param appointmentID  appointmentID
     */
    public  void setAppointmentID(int appointmentID){

        this.appointmentID = appointmentID;
    }

    /**Set method for start time  , update the start time for appointment instance
     *
     * @param appointmentStart start time
     */
    public  void setAppointmentStart(String appointmentStart){

        this.appointmentStart = appointmentStart;
    }

    /**Set method for end time  , update the end time  for appointment instance
     *
     * @param appointmentEnd end time
     */
    public  void setAppointmentEnd(String appointmentEnd){

        this.appointmentEnd=appointmentEnd;
    }

    /**Set method for description  , update the description  for appointment instance
     *
     * @param appointmentDescription  description
     */
    public  void setAppointmentDescription(String appointmentDescription){
        this.appointmentDescription= appointmentDescription;
    }

    /** Set method for location   , update the location  for appointment instance
     *
      * @param appointmentLocation location
     */

    public  void setAppointmentLocation(String appointmentLocation){
        this.appointmentLocation= appointmentLocation;
    }

    /**Set method for contact  , update the contact   for appointment instance
     *
     * @param appointmentContact  contact
     */
    public  void setAppointmentContact(String appointmentContact){

        this.appointmentContact = appointmentContact;
    }

    /**Set method for createdDate , update the createdDate  for appointment instance
     *
     * @param createdD  createdDate
     */
    public void setCreateDate(String createdD){
        this.createdD=createdD;
    }


    /**Get method for createdBy

     * @return  createdBy
     */
    public String getCreatedBy(){
          return this.createdBy;
    }

    /**Get method for customerID
     *
     * @return  customer id
     */
    public int getCustomerID(){

        return  this.customerID;
    }


    /** Get method  for appointmentID
     *
     * @return appointment ID
     */
    public int getAppointmentID(){

        return appointmentID;
    }


    /** Get method  for  userID
     *
     * @return userID
     */
    public  int getUserID(){
        return this.userID;
    }


    /**Get method  for  start time
     *
     * @return  start time
     */
    public String getAppointmentStart(){

        return this.appointmentStart;
    }


    /**Get method  for  end time
     *
     * @return  end time
     */
    public String getAppointmentEnd(){

        return this.appointmentEnd;
    }


    /**Get method  for  title
     *
     * @return  title
     */
    public String getAppointmentTitle(){
        return this.appointmentTitle;
    }

    /**Get method  for  type
     *
     * @return  type
     */
    public String getAppointmentType(){
        return this.appointmentType;
    }

    /**Get method  for description
     *
     * @return description
     */
    public String getAppointmentDescription(){

        return this.appointmentDescription;
    }

    /**Get method  for location
     *
     * @return location
     */
    public String getAppointmentLocation(){

        return this.appointmentLocation;
    }

    /**Get method  for contact
     *
     * @return contact
     */
    public String getAppointmentContact(){

        return this.appointmentContact;
    }


}