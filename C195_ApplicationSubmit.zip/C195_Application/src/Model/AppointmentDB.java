package Model;

import Database.Alerts;
import Database.SQLDatabase;
import View_Controller.ViewAppointmentsController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.IOException;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;


/**  AppointmentDB Class is used to get connected to Database and query data from appointments table.*
 */

public class AppointmentDB {

    private static String error;
    private final DateTimeFormatter dateDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd");//ISO standard date format
    private static final DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final ZoneId utcZoneID = ZoneId.of("UTC");
    private static final  ZoneId localZoneID =ZoneId.systemDefault();


    /**Get method to get counts for appointments by type and by month report
     *
     * @param month  month
     * @param type   appointment type
     * @return  counts
     * @throws SQLException  sql
     */

    public  static   Integer getCount(String month,String type) throws SQLException  {

            int  count =0;
            String query = "Select count(*) from appointments where type = '" + type + "'and monthname(Start) ='" + month + "';";
            Statement statement = SQLDatabase.getConnection().createStatement();
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()){
            count = rs.getInt("count(*)");
            System.out.println(rs);}

            return  count;
    }



    /** Method to add new appointment
     *
     * @param title title
     * @param description description
     * @param location  location
     * @param type  type
     * @param apptEnd  appointment End time
     * @param apptStart  appointment start time
     * @param customerID  customer ID
     * @param userID     userID
     * @param contactID  contact ID
     */
    public static void  addAppointment (String  title, String description, String location, String type, Timestamp apptStart, Timestamp apptEnd, int customerID, int userID, int  contactID) {


      String UserName = UserDB.getCurrentUser().getUsername();
      try {
          String query = "INSERT INTO appointments  VALUES(Null,?,?,?,?,?,?,NOW(),?,NOW(),?,?,?,?)";
          PreparedStatement ps = SQLDatabase.getConnection().prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
          ps.setString(1,title);
          ps.setString(2,description);
          ps.setString(3,location);
          ps.setString(4,type);
          ps.setTimestamp(5,apptStart);
          ps.setTimestamp(6,apptEnd);
          ps.setString(7,UserName);
          ps.setString(8, UserName);
          ps.setInt(9,customerID);
          ps.setInt(10,userID);
          ps.setInt(11,contactID);
          ps.executeUpdate();

      } catch (SQLException throwables) {
          throwables.printStackTrace();
      }
    }




    /**Method to update/modify selected Appointment
     *
     * @param title  title
     * @param description description
     * @param location  location
     * @param type type
     * @param updatedBy updatedBy
     * @param apptStart add start
     * @param apptEnd  add end
     * @param customerID  customer id
     * @param userID  user id
     * @param contactID  contact id
     */
    public static void modifyAppointment ( String  title, String description, String location, String type, String updatedBy, Timestamp apptStart,Timestamp apptEnd,int  customerID, int  userID,int  contactID) {
      int appointmentID = ViewAppointmentsController.getUpdateAppointment().getAppointmentID();
        try {
            String query = "UPDATE  appointments set Title=?,Description=?,Location=?,Type=?,Start=?,End=?,Last_Update=NOW(),Last_Updated_By=?,Customer_ID=?,User_ID=?,Contact_ID=? WHERE Appointment_ID=?";
            PreparedStatement ps = SQLDatabase.getConnection().prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, location);
            ps.setString(4, type);
            ps.setTimestamp(5, apptStart);
            ps.setTimestamp(6, apptEnd);
            ps.setString(7, updatedBy);
            ps.setInt(8, customerID);
            ps.setInt(9, userID);
            ps.setInt(10, contactID);
            ps.setInt(11,appointmentID);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    /** Get method to get All appointments
     *
     * @return all appointments
     */

    public static ObservableList<Appointment> getAllAppointment() {

         ObservableList<Appointment> allAppointment = FXCollections.observableArrayList();

         DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
         ZoneId localZoneID = ZoneId.systemDefault();
         ZoneId utcZoneID = ZoneId.of("UTC");


        try {
            Statement statement = SQLDatabase.getConnection().createStatement();
            String query = "select appointments.Appointment_ID,appointments.Title,appointments.Location,appointments.Type,appointments.Start,appointments.Create_Date,appointments.Created_By,appointments.End,appointments.Contact_ID,appointments.Customer_ID,appointments.Description,appointments.User_ID,contacts.Contact_Name from appointments,contacts where appointments.Contact_ID = contacts.Contact_ID;";
            ResultSet rs = statement.executeQuery(query);
            System.out.println("Appointment Table query worked");

             while (rs.next()){
                String createUTC = rs.getString("Create_Date").substring(0,19);


                String startUTC;
                String endUTC;
                 startUTC = rs.getString("Start").substring(0,19);
                 endUTC = rs.getString("End").substring(0,19);
                 System.out.println("startUTC"+startUTC);
                 LocalDateTime utcStartDT = LocalDateTime.parse(startUTC,datetimeDTF);
                 LocalDateTime utcEndDT = LocalDateTime.parse(endUTC,datetimeDTF);
                 System.out.println("utcStartDT"+utcStartDT);
                 ZonedDateTime localZoneStart = utcStartDT.atZone(utcZoneID).withZoneSameInstant(localZoneID);
                 System.out.println("localZoneStart"+localZoneStart);
                 ZonedDateTime localZoneEnd = utcEndDT.atZone(utcZoneID).withZoneSameInstant(localZoneID);
                 String localStartDT = localZoneStart.format(datetimeDTF);
                 System.out.println("localStartDT:"+ localStartDT);
                 String localEndDT = localZoneEnd.format(datetimeDTF);
                 System.out.println("localEndDT"+localEndDT);


                 Appointment appointment = new Appointment(

                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Location"),
                        rs.getString("Description"),
                        rs.getString("Contact_Name"),
                        rs.getString("Type"),
                        localStartDT,
                        localEndDT,
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getString("Created_By"),
                        createUTC.formatted(datetimeDTF)
                );

                allAppointment.add(appointment);
            }
            statement.close();
            return allAppointment;
        }
        catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());

        }
        return allAppointment;
    }




    /** Method to check overlapping appointments
     *
     * @param newStart start time
     * @param newEnd new time
     * @return boolean
     * @throws SQLException sql
     */
    public  static boolean checkOverlappingAppointment(ZonedDateTime newStart, ZonedDateTime newEnd) throws SQLException {

      int customerID = 0;
      if (ViewAppointmentsController.getUpdateAppointment()!=null)
      {     int appointmentID = ViewAppointmentsController.getUpdateAppointment().getAppointmentID();

            PreparedStatement ps = SQLDatabase.getConnection().prepareStatement("SELECT * From appointments WHERE (? BETWEEN Start AND End OR ? BETWEEN Start AND End OR ? < Start AND ? > End) AND (Appointment_ID != ?)");
            ps.setTimestamp(1, Timestamp.valueOf(newStart.toLocalDateTime()));
            ps.setTimestamp(2,Timestamp.valueOf(newEnd.toLocalDateTime()));
            ps.setTimestamp(3,Timestamp.valueOf(newStart.toLocalDateTime()));
            ps.setTimestamp(4,Timestamp.valueOf(newEnd.toLocalDateTime()));
            ps.setInt(5,appointmentID);

            ResultSet rs = ps.executeQuery();
            if(rs.next()) {

                customerID = rs.getInt("Customer_ID");
                System.out.println("You have an overlapping appointment with Customer_ID: "+ customerID);
                return true; }}

      else {

          PreparedStatement ps = SQLDatabase.getConnection().prepareStatement("SELECT * From appointments WHERE (? BETWEEN Start AND End OR ? BETWEEN Start AND End OR ? < Start AND ? > End )");
          ps.setTimestamp(1, Timestamp.valueOf(newStart.toLocalDateTime()));
          ps.setTimestamp(2,Timestamp.valueOf(newEnd.toLocalDateTime()));
          ps.setTimestamp(3,Timestamp.valueOf(newStart.toLocalDateTime()));
          ps.setTimestamp(4,Timestamp.valueOf(newEnd.toLocalDateTime()));
          ResultSet rs = ps.executeQuery();
          if(rs.next()) {
              customerID = rs.getInt("Customer_ID");
              System.out.println("You have an overlapping appointment with Customer_ID: "+ customerID);
              return true; }
      }

        return false;
    }



    /** Method to check  if input data is valid
     *
     * @param customerID id
     * @param title title
     * @param description description
     * @param type type
     * @param contact contact
     * @param location location
     * @param date  date
     * @param start  start
     * @param end  end
     * @param userID user id
     * @return boolean
     * @throws IOException sql
     */
    public static Boolean validateInput(int  customerID, String title, String description, String type,String contact,String location,LocalDate date,LocalTime start,LocalTime end,int  userID) throws IOException {
             error = "";
           if (!validCustomerID(customerID)||!validTitle(title)||!validDescription(description)||!validType(type)||!validContact(contact)||!validLocation(location)||!validDate(date)||!validStart(start)||!validEnd(end)||!validUserID(userID)){
            System.out.println(error);
            Alerts.infoDialog("Error","Please fix the following error: " ,error);
            return Boolean.FALSE;
           }
           else{
            return Boolean.TRUE;}
        }


    /** Method to check input for userID
     *
     * @param userID user id
     * @return   boolean
     * @throws IOException  sql
     */
    private static boolean validUserID(int  userID) throws NullPointerException{
        if (String.valueOf(userID).isEmpty()){
            error = "Please choose a userID";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
    }


    /**Method to check input for end time
     *
     * @param end end
     * @return   boolean
     * @throws IOException sql
     */
    private static boolean validEnd(LocalTime end) throws IOException {
          if (end == null){
            error = "Please choose an end time";
            return Boolean.FALSE;
          }
          else {
            return Boolean.TRUE;
          }
       }

    /**Method to check input for start time
     *
     * @param start start
     * @return   boolean
     * @throws IOException sql
     */
    private static boolean validStart(LocalTime start) throws IOException {
           if (start == null){
            error = "Please choose a start time";
            return Boolean.FALSE;
           }
           else {
            return Boolean.TRUE;
           }
       }

    /**Method to check input for date
     *
     * @param date  date
     * @return   boolean
     * @throws IOException sql
     */
    private static boolean validDate(LocalDate date) throws IOException {

           if (date==null){
           error = "Please choose a date";
           return Boolean.FALSE;
           }
           else {
           return Boolean.TRUE;
          }
        }

    /**Method to check input for id
     *
     * @param id id
     * @return   boolean
     * @throws IOException sql
     */
    private  static  boolean validCustomerID(int  id) {
            if (String.valueOf(id).isEmpty()){
            error = "Please choose a CustomerID";
            return Boolean.FALSE;}
            else {
                   return Boolean.TRUE;
               }

            }





    /**Method to check input for title
     *
     * @param title title
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validTitle(String title) throws IOException{
            if (title.isEmpty()){
            error = "Please enter a title";
            return Boolean.FALSE;
            }
            else {
            return Boolean.TRUE;
           }
        }

    /**Method to check input for description
     *
     * @param description description
     * @return   boolean
     * @throws IOException sqj
     */
    private  static  boolean validDescription(String description) throws IOException{
           if (description.isEmpty()){
            error = "Please enter a description";
            return Boolean.FALSE;
           }
           else {
            return Boolean.TRUE;
           }
        }

    /**Method to check input for type
     *
     * @param type type
     * @return  boolean
     * @throws IOException sql
     */
    private  static  boolean validType(String type) throws IOException{

        if (type.isEmpty()){
            error = "Please choose a type ";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
        }

    /**Method to check input for contact
     *
     * @param contact contact
     * @return boolean
     * @throws IOException sql
     */
     private  static  boolean validContact(String contact)throws NullPointerException{
        if (contact==null){
            error = "Please choose a Contact Name";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
        }

    /**Method to check input for  location
     *
     * @param location location
     * @return  boolean
     * @throws IOException sql
     */
    private  static  boolean validLocation(String location) throws IOException{
        if (location.isEmpty()){
            error = "Please enter a location  ";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
        }


    /** Method to delete appointment
     *
     * @param apptID appointment ID
     */
   public static void deleteAppointment(Integer apptID){
        try{
            Statement statement= SQLDatabase.getConnection().createStatement();
            String query = "DELETE FROM appointments WHERE Appointment_ID=" + apptID ;
            statement.executeUpdate(query);

            System.out.println("Successfully deleted customer");

        }
        catch (SQLException throwables){
            throwables.printStackTrace();
        }
    }



}












