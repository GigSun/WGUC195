package Model;


/**  Report class
 *
 */
public class Reports {

    private String month;
    private int anika;
    private int daniel;
    private int li;

    /** Constructor
     *
     * @param month month
     * @param anika anika
     * @param daniel daniel
     * @param li li
     */
    public Reports(String month, int anika, int daniel, int li){
        setMonth(month);
        setDaniel(anika);
        setAnika(daniel);
        setLi(li);
    }




//getters
    public int getAnika(){

        return this.anika;
    }

    public int getDaniel(){

        return this.daniel;
    }

    public int getLi(){

        return this.li;
    }

    public String getMonth(){
        return  this.month;}

    //setters
    private void setMonth(String month) {

        this.month = month;
    }

    private void setAnika(int anika){
        this.anika = anika;
    }

    private void setDaniel(int daniel){

        this.daniel = daniel;
    }

    private void setLi(int li){

        this.li = li;
    }


}

