package Model;

import Database.Alerts;
import Database.SQLDatabase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.sql.*;

/**CustomerDB class to get connection with database
 *
 */
public class CustomerDB {

    private  static final ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
    private static String error;


    /** Method to get ALL customers from database
     *
     * @return all customers
     */

    public static ObservableList<Customer>getAllCustomers(){
        allCustomers.clear();

        try {
            Statement statement = SQLDatabase.getConnection().createStatement();

        String query = "SELECT customers.Customer_ID,customers.Address,customers.Postal_Code,customers.Customer_Name,customers.Division_ID, customers.Phone,first_level_divisions.Division,countries.COUNTRY_ID ,countries.Country from customers,first_level_divisions,countries WHERE customers.Division_ID = first_level_divisions.Division_ID AND first_level_divisions.COUNTRY_ID = countries.COUNTRY_ID;";
            ResultSet rs = statement.executeQuery(query);

        while (rs.next()){
        Customer customer = new Customer(
                rs.getInt("Customer_ID"),
                rs.getString("Customer_Name"),
                rs.getString("Address"),
                rs.getString("Postal_Code"),
                rs.getString("Phone"),
                rs.getInt("Division_ID"),
                rs.getString("Division"),
        rs.getString("Country"));

        allCustomers.add(customer);
                }
        statement.close();
        return allCustomers;
        }
        catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());
            return null;
        }
    }


    /**Method to get customerID
     *
     * @return customer ID
     * @throws SQLException sql
     */
    public  static ObservableList<Integer> getCustomerID() throws SQLException{
        ObservableList<Integer> customerIDList =FXCollections.observableArrayList();
        Statement statement = SQLDatabase.getConnection().createStatement();

       String query = "SELECT * from customers;";
       ResultSet rs = statement.executeQuery(query);
       while (rs.next()){
           int customerID = rs.getInt("Customer_ID");
           customerIDList.add(customerID);
       }

        return  customerIDList;
}


    /** Method to addCustomer to database with attributes
     *
     * @param name name
     * @param address address
     * @param phone phone
     * @param zip zip
     * @param divisionID division ID
     * @throws SQLException sql
     */
    public static  void addCustomer(String name, String address, String phone,String zip, Integer divisionID) throws SQLException {
        String currentUser = UserDB.getCurrentUser().getUsername();

        try {
            String query = "INSERT INTO customers VALUES(NULL,?,?,?,?,NOW(),?,NOW(),?,?)";
            PreparedStatement ps = SQLDatabase.getConnection().prepareStatement(query,Statement.RETURN_GENERATED_KEYS);

            ps.setString(1,name);
            ps.setString(2,address);
            ps.setString(3,zip);
            ps.setString(4,phone);
            ps.setString(5,currentUser);
            ps.setString(6,currentUser);
            ps.setInt(7,divisionID);
            ps.executeUpdate();

        }
        catch (SQLException e){
            e.printStackTrace();
        }
}


    /** Method to Modify Customer to database with attributes
     *
     * @param id id
     * @param name name
     * @param address address
     * @param phone phone
     * @param zip  zip
     * @param divisionID  division ID
     * @throws SQLException sql
     */
    public static  void modifyCustomer(Integer id,String name, String address, String phone,String zip, Integer divisionID) throws SQLException {
        String currentUser = UserDB.getCurrentUser().getUsername();

        try {
            String query = "UPDATE  customers set Customer_Name =?,Address =?,Postal_Code=?,Phone=?,Create_Date=NOW(),Created_By=?,Last_Update =NOW(),Last_Updated_By=? ,Division_ID=? WHERE Customer_ID=?";
            PreparedStatement ps = SQLDatabase.getConnection().prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setInt(8,id);
            ps.setString(1,name);
            ps.setString(2,address);
            ps.setString(3,zip);
            ps.setString(4,phone);
            ps.setString(5,currentUser);
            ps.setString(6,currentUser);
            ps.setInt(7,divisionID);

            ps.executeUpdate();

        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }


    /** Method to delete customer from database
     *
     * @param customerID id
     */

   public  static  void deleteCustomer(Integer customerID){
        try{

            //delete appointment with customer_ID
            String query2 = "DELETE  FROM appointments WHERE appointments.Customer_ID=?";
            PreparedStatement ps2 = SQLDatabase.getConnection().prepareStatement(query2);
            ps2.setInt(1,customerID);
            ps2.execute();

            //delete customers table with customer_ID
            String query1 = "DELETE  FROM customers WHERE customers.Customer_ID=? ";
            PreparedStatement ps = SQLDatabase.getConnection().prepareStatement(query1);
            ps.setInt(1,customerID);
            ps.execute();

            System.out.println("Successfully deleted customer");
        }

        catch (SQLException throwables){
            throwables.printStackTrace();
        }
   }


    /** Method to check input validation
     *
     * @param name name
     * @param phone phone
     * @param address address
     * @param zip zip
     * @param state state
     * @param country country
     * @return  boolean
     * @throws IOException sql
     */
   public static Boolean validateCustomer(String name, String phone , String address, String zip,String state,String country) throws IOException {
        error = "";
        if (!validZip(zip)||!validName(name)||!validPhone(phone)||!validAddress(address)||!validState(state)||!validCountry(country)){
            System.out.println(error);
            Alerts.infoDialog("Error","Please fix the following error: " ,error);
            return Boolean.FALSE;
        }
        else{
            return Boolean.TRUE;
        }
   }


    /**Method to valid zip
     *
     * @param zip zip
     * @return boolean
     * @throws IOException sql
     */
   private  static  boolean validZip(String zip) throws IOException{
        if (zip.isEmpty()){
            error = "Please enter a Zip";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
   }


    /**Method to valid address
     *
     * @param address address
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validAddress(String address) throws NullPointerException{
        if (address.isEmpty()){
            error = "Please enter a City";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
    }



    /**Method to valid phone
     *
     * @param  phone  phone
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validPhone(String phone) throws IOException{
        if (phone.isEmpty()){
            error = "Please enter a Phone Number";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
    }



    /**Method to valid state
     *
     * @param state state
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validState(String state) throws NullPointerException{
        if (state==null){
            error = "Please choose a state ";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
    }



    /**Method to valid name
     *
     * @param name name
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validName(String name)throws IOException{
        if (name.isEmpty()){
            error = "Please enter a Customer Name";
            return Boolean.FALSE;
        }
        else {
            return Boolean.TRUE;
        }
    }



    /**Method to valid country
     *
     * @param country country
     * @return boolean
     * @throws IOException sql
     */
    private  static  boolean validCountry(String country) throws NullPointerException{
            if (country==null){
                error = "Please choose a country ";
                return Boolean.FALSE;
            }
            else {
                return Boolean.TRUE;
            }
    }
}







