package Model;

import Database.SQLDatabase;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**UserDB class get currentUser
 *
 */
public class UserDB {

    private static User currentUser;


        /**Method to get current login user
         *

         * @return   current user object
         */
        public static User getCurrentUser() {

            return currentUser;
        }



        /** Method to  get valid login boolean
         *
         * @param Username  login username
         * @param Password  login pw
         * @return ture
         */

        public static Boolean login(String Username, String Password) throws SQLException{

            Statement statement = SQLDatabase.getConnection().createStatement();
            String logger= "SELECT * FROM users WHERE User_Name ='"+Username+"'AND Password='"+Password+"'";
            ResultSet rs = statement.executeQuery(logger);

            if (rs.next()) {
                currentUser  = new User();
                currentUser.setUsername(rs.getString("User_Name"));
                currentUser.setUserID(rs.getInt("User_ID"));
                statement.close();
                return Boolean.TRUE;
            }
            else {
                return Boolean.FALSE;

            }
        }



}





