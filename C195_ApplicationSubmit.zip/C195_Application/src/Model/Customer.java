package Model;

import java.util.Date;

/**  Customer  Class defines methods and attributes for Appointment.*/
public class Customer {
    private  int customerID ;
    private  String customerName ;
    private  int  customerDivisionID ;
    private  String  customerAddress;
    private  String  customerZip ;
    private  String customerPhone ;
    private  String customerCountry;
    private Date createDate;
    private String createdBy;
    private  String lastUpdate;
    private  String lastUpdateBy;
    private String customerDivision;

    /** Constructor
     *
     */
    public Customer(){}

    /**Constructor
     *
     * @param customerID customer ID
     * @param name name
     * @param address address
     * @param zip zip
     * @param phone  phone
     * @param customerDivisionID division ID
     * @param customerDivision  division
     * @param customerCountry country
     */
    public Customer(int customerID , String name, String address, String zip, String phone,int customerDivisionID,String customerDivision,String customerCountry){

        setCustomerID(customerID);
        setCustomerName(name);
        setCustomerAddress(address);
        setCustomerZip(zip);
        setCustomerPhone(phone);
        setCustomerDivisionID(customerDivisionID);
        setCustomerDivision(customerDivision);
        setCustomerCountry(customerCountry);

    }


    /**Constructor
     *
     * @param customerID id
     * @param customerName  name
     */
    public  Customer(int customerID,String customerName){
        setCustomerID(customerID);
        setCustomerName(customerName);
    }


    /**Get method for customer id
     *
     * @return id
     */

    public int getCustomerID(){ return  customerID; }

    /**Set method for customer ID
     *
     * @param customerID  customer id
     */
    public void  setCustomerID(int customerID){ this.customerID = customerID; }

    /**Set method for customer Division ID
     *
     * @param customerDivisionID id
     */
    public void  setCustomerDivisionID(int customerDivisionID){ this.customerDivisionID = customerDivisionID; }

    /**Get method for customer Division ID
     *
     * @return id
     */
    public int getCustomerDivisionID(){ return  customerDivisionID; }

    /**Get method for address
     *
     * @return address
     */
    public String getCustomerAddress(){ return customerAddress; }

    /**Set method for address
     *
     * @param customerAddress address
     */
    public void  setCustomerAddress(String customerAddress){ this.customerAddress = customerAddress; }

    /**Get method for division
     *
     * @return division
     */
    public String getCustomerDivision(){ return customerDivision; }

    /**Set mothod for division
     *
     * @param customerDivision division
     */
    public void  setCustomerDivision(String customerDivision){ this.customerDivision = customerDivision; }

    /**Get method for country
     *
     * @return country
     */
    public String getCustomerCountry(){ return customerCountry; }


    /**Set method for country
     *
     * @param customerCountry country
     */
    public void  setCustomerCountry(String customerCountry){ this.customerCountry = customerCountry; }

    /**Get method for phone
     *
     * @return phone
     */
    public String getCustomerPhone(){ return customerPhone; }

    /**Set method for phone
     *
     * @param customerPhone phone
     */
    public void  setCustomerPhone(String customerPhone){ this.customerPhone = customerPhone; }

    /**Get method for zip
     *
     * @return ziop
     */
    public String getCustomerZip(){ return customerZip; }

    /**Set method for zip
     *
     * @param customerZip zip
     */
    public void  setCustomerZip(String customerZip){ this.customerZip = customerZip; }

    /** Get method
     *
     * @return customer Name
     */
    public String getCustomerName(){ return customerName; }

    /** Set method for name
     *
     * @param customerName name
     */
    public void  setCustomerName(String customerName){ this.customerName = customerName; }



    public String getCustomerLastUpdate(){ return lastUpdate; }
    public void  setCustomerLastUpdate(String lastUpdate){ this.lastUpdate = lastUpdate; }

    public String getCustomerLastCreateBy(){ return lastUpdateBy; }
    public void  setCustomerLastUpdateBy(String lastUpdateBy){ this.lastUpdateBy = lastUpdateBy; }



}
