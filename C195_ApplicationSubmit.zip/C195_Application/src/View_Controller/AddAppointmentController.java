package View_Controller;


import Database.Alerts;
import Model.AppointmentDB;
import Model.CustomerDB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;


public class AddAppointmentController implements Initializable {


    private final ObservableList<String> startTimes = FXCollections.observableArrayList();
    private final ObservableList<String> endTimes = FXCollections.observableArrayList();
    private final DateTimeFormatter timeDTF = DateTimeFormatter.ofPattern("HH:mm:ss");//ISO standard time formaat
    private final  ZoneId localZoneID =ZoneId.systemDefault();
    private final ObservableList<String> contacts = FXCollections.observableArrayList("Anika Costa", "Daniel Garcia", "Li Lee");
    private final ObservableList<String> userID = FXCollections.observableArrayList("1-test", "2-admin");



    @FXML
    static TextField AppointmentIDTextField;
    @FXML
     ComboBox<Integer> CustomerIDComboBox;
    @FXML
    TextField AppointmentTitleTextField;
    @FXML
    TextField AppointmentDescriptionTextField;
    @FXML
    TextField AppointmentTypeTextField;
    @FXML
    TextField AppointmentLocationTextField;
    @FXML
    ComboBox<String> AppointmentContactComboBox;
    @FXML
    ComboBox<String> AppointmentStartComboBox;
    @FXML
    ComboBox<String> AppointmentEndComboBox;
    @FXML
    ComboBox<String> UserIDComboBox;
    @FXML
    DatePicker AppointmentDatePicker;


    /** Method to initial table
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        AppointmentContactComboBox.setItems(contacts);
        UserIDComboBox.setItems(userID);
        try {
            CustomerIDComboBox.setItems(CustomerDB.getCustomerID());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        CustomerIDComboBox.getSelectionModel().select(0);//set ID Box selected with index 0.

        UserIDComboBox.getSelectionModel().select(0);// set UserID Box selected with index 0.
        LocalDate date =LocalDate.now();
        AppointmentDatePicker.setValue(date);// set DatePicker Box selected with current date.
        fillStartTimesList();// set Start and End Box selected with first time option.

    }



    /** Method to save appointments to database
     *
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     */
    @FXML
    public void AppointmentSaveButtonHandler(ActionEvent actionEvent) throws IOException, NullPointerException,SQLException {

        LocalDate addDate = AppointmentDatePicker.getValue();
        String addLocation = AppointmentLocationTextField.getText();
        String addContact = AppointmentContactComboBox.getValue();
        int addCustomerID =  CustomerIDComboBox.getValue();
        String addTitle = AppointmentTitleTextField.getText();
        String addType = AppointmentTypeTextField.getText();
        int addUserID = Integer.parseInt(UserIDComboBox.getValue().substring(0,1));
        String addDescription = AppointmentDescriptionTextField.getText();
        LocalTime  addStart = LocalTime.parse(AppointmentStartComboBox.getSelectionModel().getSelectedItem(),timeDTF);
        LocalTime addEnd = LocalTime.parse(AppointmentEndComboBox.getSelectionModel().getSelectedItem(),timeDTF);
        LocalDateTime startDT = LocalDateTime.of(addDate,addStart);

        LocalDateTime endDT = LocalDateTime.of(addDate,addEnd);

        System.out.println("LocalStartDT: " + startDT);
        System.out.println("LocalEndDT: "+ endDT);
        ZonedDateTime startUTC = startDT.atZone(localZoneID).withZoneSameInstant(ZoneId.of("UTC"));
        ZonedDateTime endUTC = endDT.atZone(localZoneID).withZoneSameInstant(ZoneId.of("UTC"));
        System.out.println("StartUTC: " + startUTC);
        System.out.println("EndUTC: "+ endUTC);
        ZoneId etZoneId = ZoneId.of("America/New_York");
        ZonedDateTime startEST = startDT.atZone(localZoneID).withZoneSameInstant(etZoneId);
        ZonedDateTime endEST = endDT.atZone(localZoneID).withZoneSameInstant(etZoneId);//
        System.out.println("StartEST: " + startEST);
        System.out.println("EndEST: "+ endEST);
        Timestamp sqlStartTS = Timestamp.valueOf(startUTC.toLocalDateTime());
        Timestamp sqlEndTS = Timestamp.valueOf(endUTC.toLocalDateTime());
        System.out.println("sqlStartTime: "+ sqlStartTS);
        System.out.println("sqlEndTime: "+ sqlEndTS);


        if(!startEST.isBefore(endEST)){ Alerts.errorDialog("Please correct the Error","Start time is after End time","Start time must be before end time!");  return;  }
        if(AppointmentDB.checkOverlappingAppointment(startUTC, endUTC) == Boolean.TRUE){
            Alerts.errorDialog("Please correct the Error","Overlapping appointment","There is an overlapping appointment in database,\nPlease choose an another Start/End time.");
            return;
        }
        if(AppointmentDB.validateInput(addCustomerID,addTitle, addDescription, addType, addContact, addLocation, addDate, addStart, addEnd, addUserID)==Boolean.TRUE){

            System.out.println("No blank input");
            if(isWithinBusinessHours(startEST)&&isWithinBusinessHours(endEST)){
                System.out.println("Success");
                AppointmentDB.addAppointment(addTitle,addDescription,addLocation,addType,sqlStartTS,sqlEndTS,addCustomerID,addUserID,getContactID());
            }
            else {Alerts.errorDialog("Please correct the Error","Appointment has been scheduled out of business hour ","Please schedule an appointment within business hour,\n which is Monday -Sunday 8am-10pm, EST");}}


    }


    /** Method to verify if selected the datetime is within ETS business Hour
     *
     * @param zdt ETS zone date time
     * @return ture
     */

    public boolean isWithinBusinessHours(ZonedDateTime zdt) {
        LocalTime START = LocalTime.of(8, 0);
        LocalTime STOP = LocalTime.of(22, 0);
        LocalTime localTime = zdt.toLocalTime();

        if (localTime.isBefore(START)){
            return false;
        }
        if (localTime.isAfter(STOP)){
            return false;
        }
        return true;

       }


    /**Method to get contact ID
     *
     * @return contact id
     * @throws IOException sql
     */
   public int getContactID() throws IOException{

        int addContactID=1;
        if( AppointmentContactComboBox.getSelectionModel().getSelectedIndex() == 0) {
           addContactID = 1;
           }
        if(AppointmentContactComboBox.getSelectionModel().getSelectedIndex() ==1){
           addContactID = 2;
           }
        if(AppointmentContactComboBox.getSelectionModel().getSelectedIndex() == 2){
           addContactID = 3;
           }
        return addContactID;
    }


    /**Method to cancel action
     *
     * @param actionEvent action
     * @throws IOException io
     */
    public void AppointmentCancelButtonHandler(ActionEvent actionEvent) throws NoSuchElementException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Please confirm action");
        alert.setHeaderText("Are you sure you want to cancel ?");
        Optional<ButtonType> result= alert.showAndWait();
        if (result.get()== ButtonType.OK){
            clearTable();
        }
        else {
            System.out.println("You action has been cancelled");

        }

       }

    /** Method to clear input value and set to default value
     *
     */
     public void clearTable(){
        AppointmentLocationTextField.setText("");
        AppointmentDescriptionTextField.setText("");
        AppointmentContactComboBox.setValue("");

        AppointmentTypeTextField.setText("");
        AppointmentTitleTextField.setText("");
        AppointmentStartComboBox.getSelectionModel().select(LocalTime.of(0, 0, 0).format(timeDTF));
        AppointmentEndComboBox.getSelectionModel().select(LocalTime.of(0, 30, 0).format(timeDTF));
        CustomerIDComboBox.getSelectionModel().select(0);//set ID Box selected with index 0.
        UserIDComboBox.getSelectionModel().select(0);// set UserID Box selected with index 0.
        LocalDate date =LocalDate.now();
        AppointmentDatePicker.setValue(date);// set DatePicker Box selected with current date.
      }



    /**Method to fill StartTime and EndTime comboBox
     *
     */
      private void fillStartTimesList() {

        LocalTime time = LocalTime.of(0, 0, 0);
        do {
            startTimes.add(time.format(timeDTF));
            endTimes.add(time.format(timeDTF));
            time = time.plusMinutes(30);
        } while (!time.equals(LocalTime.of(0, 0, 0)));

        AppointmentStartComboBox.setItems(startTimes);
        AppointmentEndComboBox.setItems(endTimes);
        AppointmentStartComboBox.getSelectionModel().select(LocalTime.of(0, 0, 0).format(timeDTF));
        AppointmentEndComboBox.getSelectionModel().select(LocalTime.of(0, 30, 0).format(timeDTF));
       }


    /** Method to Return to Appointment Main menu.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void AppointmentBackButtonHandler(ActionEvent actionEvent) throws IOException {
        Parent root;

        root = FXMLLoader.load(getClass().getResource("ViewAppointments.fxml"));
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

      }


       public void AppointmentDatePickerHandler(ActionEvent actionEvent) {
      }
}
