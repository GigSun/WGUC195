package View_Controller;

import Database.SQLDatabase;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;

/**  MainScreenController Class to display and control  Application mainscreen
 *
 */

public class MainScreenController implements Initializable {


    /**Method to take action when customer Button is pressed.
     *
     * @param actionEvent action
     * @throws IOException exception
     */

    public void customerButtonPressed(ActionEvent actionEvent) throws IOException {

        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("customer.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    /**Method to take action when appointment  Button is pressed.
     *
     * @param actionEvent action
     * @throws IOException io exception
     */
    public void appointmentButtonPressed(ActionEvent actionEvent) throws IOException{
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("ViewAppointments.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**Method to take action when report  Button is pressed.
     *
     * @param actionEvent action
     * @throws IOException io
     */
    public void reportButtonPressed(ActionEvent actionEvent) throws  IOException{
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("Report.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    /** Method to initialize display windows.
     *
     * @param url url
     * @param resourceBundle rb
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void exitButtonPressed(ActionEvent actionEvent) throws NoSuchElementException {
       Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
       alert.setTitle("Are you sure to exit?");
       alert.setHeaderText("Confirm Exit");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            SQLDatabase.disconnect();
            System.out.println("Program closed");
            System.exit(0);
        }

        else {System.out.println("Exit cancelled");}

    }
}
