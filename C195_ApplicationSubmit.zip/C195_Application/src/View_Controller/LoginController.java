package View_Controller;

import Database.Alerts;
import Database.SQLDatabase;
import Database.TimeZoneClass;
import Model.Appointment;
import Model.AppointmentDB;
import Model.User;
import Model.UserDB;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;



public class LoginController  implements Initializable {


    @FXML
    TextField username;
    @FXML
    TextField password;
    @FXML
    Label labelUN;
    @FXML
    Label labelPW;
    @FXML
    Label zoneID;
    @FXML
    Button loginButton;
    @FXML
    Button exitButton;


    private  String  alertTitle;
    private  String alertHeader;
    private  String alertContext;
    private  String  confirmTitle;
    private  String confirmContext;
    private  String  infoTitle;
    private  String infoHeader;
    private  String infoContext1;
    private  String infoContext2;



    DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    /**Method to initialize window.
     *
     * @param location
     * @param rb
     */
    @Override
    public void initialize(URL location , ResourceBundle rb) {
        zoneID.setText(TimeZoneClass.getTimeZone());// set label with local zone ID

        //initial button , error message value based on system default locale.
        Locale locale = Locale.getDefault();//
        rb = ResourceBundle.getBundle("language_files/rb",locale);
            labelUN.setText(rb.getString("Username"));
            labelPW.setText(rb.getString("Password"));
            loginButton.setText(rb.getString("login"));
            exitButton.setText(rb.getString("Exit"));
            alertContext = rb.getString("alertContext");
            alertHeader = rb.getString("alertHeader");
            alertTitle = rb.getString("alertTitle");
            confirmTitle = rb.getString("confirmTitle");
            confirmContext=rb.getString("confirmContext");
            infoTitle=rb.getString("infoTitle");
            infoHeader=rb.getString("infoHeader");
            infoContext1=rb.getString("infoContext1");
            infoContext2=rb.getString("infoContext2");

    }




    /**Method to take action when login button is pressed.
     *
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void loginButtonPressed(ActionEvent actionEvent) throws SQLException,IOException {
        String usernameI = username.getText();
        String passwordI = password.getText();
        int userID = getUserID(usernameI);
        boolean validUser = UserDB.login(usernameI,passwordI);
        User user = new User();
        user.setUserID(userID);
        user.setUsername(usernameI);
        if(validUser){

            loginLog(user.getUsername(),true,"Login Attempt");
            appointmentAlert();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

        else {
            loginLog(user.getUsername(),false,"Login Attempt");
            Alerts.errorDialog(alertTitle,alertHeader,alertContext);

        }
    }

    /** Method to generate loginLog
     *
     * @param username username
     */
    public  void loginLog (String username,boolean success, String message) {
        try {

            String fileName = "Login_Activity.txt";
            FileWriter fw = new FileWriter(fileName, true);
            BufferedWriter bw = new BufferedWriter(fw);

            Timestamp ts = Timestamp.valueOf(LocalDateTime.now());
            String currentDT = ts.toString().substring(0,19);
            bw.append(username+" " +(success ?"Successful":"Failed")+" "+message+" "+ currentDT +" "+TimeZoneClass.getTimeZone()+ "\n");
            System.out.println("New login recorded in log file");
            bw.flush();
            bw.close();

        } catch (IOException e) {
            System.out.println("Logger Error: " + e.getMessage());
        }
    }







    /** Method to take action when exit button is pressed
     *
     * @param actionEvent
     * @throws IOException
     */

    public void exitButtonPressed(ActionEvent actionEvent) throws  IOException{

            Alerts.confirmDialog(confirmTitle,confirmContext);
            System.exit(0);}








    /**
     * Method to filter the reminder list and alerts if appointment is within 15min.
     *<p><b>
     * lambda expression used to efficiently identify any appointment starting within the next 15min
     *</b></p>
     */

    private void appointmentAlert(){
            ObservableList<Appointment> appointmentReminderOL = AppointmentDB.getAllAppointment();
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime nowPLus15Min = now.plusMinutes(15);
            System.out.println("Now: "+ now);
            System.out.println("NowPlus15: "+ nowPLus15Min);
            FilteredList<Appointment>filteredData = new FilteredList<>(appointmentReminderOL);

            filteredData.setPredicate(row ->{

                LocalDateTime rowDate = LocalDateTime.parse(row.getAppointmentStart(),datetimeDTF);
                return  rowDate.isAfter(now.minusMinutes(1))&&rowDate.isBefore(nowPLus15Min);
            });

            if(filteredData.isEmpty()){
                Alerts.infoDialog(infoTitle,infoHeader,infoContext1);
            }
            else {

                int  customerID = filteredData.get(0).getCustomerID();
                String end =filteredData.get(0).getAppointmentEnd().substring(0,16);
                String start = filteredData.get(0).getAppointmentStart().substring(0,16);


                Alerts.infoDialog(infoTitle,infoHeader,infoContext2 +"\n"+ customerID +"\n" + start + "\n" +end );}


                }







    /** Method to get userID with username parameter
     *
     * @param username username
     * @return userID
     * @throws SQLException
     */
    private int getUserID(String username) throws SQLException {
        int userID = -1;

        Statement statement = SQLDatabase.getConnection().createStatement();
        String sqlStatement = "SELECT User_ID FROM users WHERE User_Name ='" + username + "'";
        ResultSet result = statement.executeQuery(sqlStatement);

        while (result.next()) {
            userID = result.getInt("User_Id");
        }
        return userID;
    }



    }




