package View_Controller;

import Database.SQLDatabase;
import Model.Customer;
import Model.CustomerDB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;


public class customerController implements Initializable {



    @FXML
    TextField name;
    @FXML
    TextField id;
    @FXML
    TextField phone;
    @FXML
    TextField address;

    @FXML
    TextField ZipCode;


    @FXML
    private ComboBox<String> country;
    @FXML
    private ComboBox<String> state;
    @FXML
    TableColumn<Customer,Integer>customerIDColumn;
    @FXML
    TableColumn<Customer,String>customerNameColumn;
    @FXML
    TableColumn<Customer,String>customerPhoneColumn;
    @FXML
    TableColumn<Customer,Integer>divisionIDColumn;
    @FXML
    TableColumn<Customer,String>divisionColumn;
    @FXML
    TableView<Customer>CustomerTable;

    ObservableList<String> countries = FXCollections.observableArrayList("U.S","UK","Canada");
    ObservableList<String> states;
    Parent root;
    Stage stage;
    private  static Customer selectedCustomer = new Customer();


    /**Method to initialize screen
     *
     * @param location location
     * @param resourcs resource
     */
    @Override
    public void initialize(URL location, ResourceBundle resourcs)  {
        country.setItems(countries);//Populate country combo with values


        //Populate CustomerTable with values
        PropertyValueFactory<Customer,String>customerNameFactory = new PropertyValueFactory<>("customerName");
        PropertyValueFactory<Customer,String>customerPhoneFactory = new PropertyValueFactory<>("CustomerPhone");
        PropertyValueFactory<Customer,Integer>customerIDFactory = new PropertyValueFactory<>("CustomerID");
        PropertyValueFactory<Customer,Integer>DivisionIDFactory=new PropertyValueFactory<>("CustomerDivisionID");
        PropertyValueFactory<Customer,String>DivisionFactory = new PropertyValueFactory<>("CustomerDivision");
        customerIDColumn.setCellValueFactory(customerIDFactory);
        customerNameColumn.setCellValueFactory(customerNameFactory);
        customerPhoneColumn.setCellValueFactory(customerPhoneFactory);
        divisionIDColumn.setCellValueFactory(DivisionIDFactory);
        divisionColumn.setCellValueFactory(DivisionFactory);
        CustomerTable.setItems(CustomerDB.getAllCustomers());

        id.setText("Auto");


    }

    /**Method to fill states ComboBox
     *
     */
    public  void onCountrySelected(){

        int  currentCountry = country. getSelectionModel().getSelectedIndex();

        if(currentCountry ==0 ){
            states = FXCollections.observableArrayList("Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","IllinoisIndiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","MontanaNebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","PennsylvaniaRhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming");
            state.setItems(states);
        }
        if(currentCountry == 1){
            states = FXCollections.observableArrayList("England","Wales","Scotland");}
            state.setItems(states);
        if(currentCountry == 2){
            states =FXCollections.observableArrayList("Ontario","Quebec","Saskatchewan","Nunavut","Yokon","Newfoundland and Labrador");
            state.setItems(states);
        }


    }

    /**Method to save customer instance to database.
     *
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     * @throws NumberFormatException
     */
    @FXML
    public void saveButtonPressed(ActionEvent actionEvent) throws IOException, SQLException,NumberFormatException {
        String addName = name.getText();
        String addPhone = phone.getText();
        String addStreet = address.getText();
        String addZip = ZipCode.getText();
        String addState = state.getValue();
        String addCountry = country.getValue();

        selectedCustomer = CustomerTable.getSelectionModel().getSelectedItem();
        if (selectedCustomer== null) {

            if (CustomerDB.validateCustomer(addName, addPhone, addStreet, addZip,addState,addCountry) == Boolean.TRUE) {
                CustomerDB.addCustomer(addName, addPhone, addStreet, addZip, getDivisionID());
                updateCustomerTable();
                clearTable();
                System.out.println("Customer has been successfully added to the database");
            }
        }


        else {


            int addCustomerID = selectedCustomer.getCustomerID();
            if (CustomerDB.validateCustomer(addName, addPhone, addStreet, addZip,addState,addCountry) == Boolean.TRUE) {


                CustomerDB.modifyCustomer(addCustomerID,addName, addPhone, addStreet, addZip,getDivisionID() );
                updateCustomerTable();
                clearTable();
                System.out.println("Customer has been successfully updated to the database");
            }


        }

        }


    /**Method to get customer division ID
     *
     * @return division ID
     * @throws SQLException sql
     */
    public int getDivisionID() throws SQLException{

    int addDivisionID=1;
    Statement statement = SQLDatabase.getConnection().createStatement();
    String query = "SELECT Division,Division_ID from first_level_divisions;";
    ResultSet rs = statement.executeQuery(query);
    while (rs.next()) {
        String addState = state.getValue();
        if ((rs.getString("Division").compareToIgnoreCase(addState))==0) {
            addDivisionID=rs.getInt("Division_ID");

        }
        }
    return addDivisionID;
}


    /**Method to switch  to MainScreen view
     *
     * @param actionEvent
     * @throws IOException
     */

@FXML
    public void backButtonPressed(ActionEvent actionEvent) throws  IOException{
        root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }




    /**Method to cancel item.
     *
     * @param actionEvent
     */
    @FXML
    public void cancelButtonSelected(ActionEvent actionEvent)  {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Please confirm action");
        alert.setHeaderText("Are you sure you want to cancel ?");
        Optional<ButtonType> result= alert.showAndWait();
        if (result.get()== ButtonType.OK){
            clearTable();
        }
        else {
            System.out.println("You action has been cancelled");
        }

    }


    /** Method to delete customer instance
     *
     * @param actionEvent
     * @throws Exception
     */

  @FXML
    public void deleteButtonPressed(ActionEvent actionEvent) throws Exception {
        if (CustomerTable.getSelectionModel().getSelectedItem() != null){
            selectedCustomer = CustomerTable.getSelectionModel().getSelectedItem();

            Integer custID = selectedCustomer.getCustomerID();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Please confirm action");
            alert.setHeaderText("Are you sure you want to delete this customer ?");
            Optional<ButtonType> result= alert.showAndWait();
            if (result.get()== ButtonType.OK){
                System.out.println("Deleting customer");
                CustomerDB.deleteCustomer(custID);
                updateCustomerTable();
                clearTable();
            }
            else {System.out.println("Delete was cancelled");}
        }


    }


    /**
     * Method to update customer table
     * @throws SQLException
     */

    private void updateCustomerTable() throws SQLException {
        CustomerTable.setItems(CustomerDB.getAllCustomers());
        System.out.println("Customer Table has been updated");

    }


    /**
     * Method to edit /update  customer data.
     * @param actionEvent
     * @throws Exception
     */
    @FXML
    private void editButtonPressed(ActionEvent actionEvent) throws Exception{

        if (CustomerTable.getSelectionModel().getSelectedItem() != null){
            selectedCustomer = CustomerTable.getSelectionModel().getSelectedItem();

            setCustomer(selectedCustomer);
        }
        else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error message");
        alert.setHeaderText("Please select an item to update");
        Optional<ButtonType> result= alert.showAndWait();


        }
    }


    /**  Method to populate customer update table.
     *
     * @param selectedCustomer  selected customer.
     */
    public  void setCustomer (Customer selectedCustomer){
        this.selectedCustomer = selectedCustomer;
        name.setText(selectedCustomer.getCustomerName());
        phone.setText(selectedCustomer.getCustomerPhone());
        address.setText(selectedCustomer.getCustomerAddress());
        ZipCode.setText(selectedCustomer.getCustomerZip());
        state.setValue(selectedCustomer.getCustomerDivision());
        country.setValue(selectedCustomer.getCustomerCountry());
        id.setText(String.valueOf(selectedCustomer.getCustomerID()));

    }

    /**
     * Method to clear Table.
     */
    public void clearTable(){
        name.setText("");
        phone.setText("");
        state.setValue("");
        country.setValue("");
        address.setText("");
        ZipCode.setText("");
        id.setText("auto");

    }
}

    


