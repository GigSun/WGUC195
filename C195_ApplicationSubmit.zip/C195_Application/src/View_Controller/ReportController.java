package View_Controller;

import Database.SQLDatabase;
import Model.Appointment;
import Model.AppointmentDB;
import Model.Reports;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class ReportController implements Initializable {


    @FXML
    ComboBox<String> AppointmentByMonthComboBox;
    @FXML
    ComboBox<String> AppointmentByTypeComboBox;
    @FXML
    TextField numberTextField;
    @FXML
    private TableView<Appointment> ReportsScheduleTableView;
    @FXML
    private TableColumn<Appointment, Integer> ReportsScheduleAppointmentIDColumn;
    @FXML
    private TableColumn<Appointment, Integer> ReportsScheduleCustomerIDColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleTitleColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleTypeColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleDescriptionColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleStartColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleEndColumn;
    @FXML
    private TableColumn<Appointment, String> ReportsScheduleContactColumn;

    @FXML
    private TableView<Reports> ReportsContactsByMonthTableView;
    @FXML
    private TableColumn<Reports, String> ReportsContactsMonthColumn;
    @FXML
    private TableColumn<Reports, Integer> ReportsContactAColumn;
    @FXML
    private TableColumn<Reports, Integer> ReportsContactDColumn;
    @FXML
    private TableColumn<Reports, Integer> ReportsContactLColumn;

    Parent root;
    Stage stage;


    private final DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final ZoneId localZoneID = ZoneId.systemDefault();
    private final ZoneId utcZoneID = ZoneId.of("UTC");
    private final ObservableList<String> month = FXCollections.observableArrayList("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

    // array to store counts for each contact in each month
    private final int[][] monthContacts = new int[][]{
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},
            {0, 0, 0},

    };



    /** Method to initialize the window
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Populate Contacts Schedule  table
        PropertyValueFactory<Appointment, Integer> apptIDFactory = new PropertyValueFactory<>("appointmentID");
        PropertyValueFactory<Appointment, Integer> apptCustomerIDFactory = new PropertyValueFactory<>("customerID");
        PropertyValueFactory<Appointment, String> apptStartFactory = new PropertyValueFactory<>("appointmentStart");
        PropertyValueFactory<Appointment, String> apptEndFactory = new PropertyValueFactory<>("appointmentEnd");
        PropertyValueFactory<Appointment, String> apptTitleFactory = new PropertyValueFactory<>("appointmentTitle");
        PropertyValueFactory<Appointment, String> apptTypeFactory = new PropertyValueFactory<>("appointmentType");
        PropertyValueFactory<Appointment, String> apptDescriptionFactory = new PropertyValueFactory<>("appointmentDescription");
        PropertyValueFactory<Appointment, String> apptContactFactory = new PropertyValueFactory<>("appointmentContact");
        //assign cell values to Schedule Report
        ReportsScheduleStartColumn.setCellValueFactory(apptStartFactory);
        ReportsScheduleEndColumn.setCellValueFactory(apptEndFactory);
        ReportsScheduleCustomerIDColumn.setCellValueFactory(apptCustomerIDFactory);
        ReportsScheduleTitleColumn.setCellValueFactory(apptTitleFactory);
        ReportsScheduleTypeColumn.setCellValueFactory(apptTypeFactory);
        ReportsScheduleDescriptionColumn.setCellValueFactory(apptDescriptionFactory);
        ReportsScheduleAppointmentIDColumn.setCellValueFactory(apptIDFactory);
        ReportsScheduleContactColumn.setCellValueFactory(apptContactFactory);


        //Populate By Types and By Month  Combo and display numbers.

        AppointmentByMonthComboBox.setItems(month);


        //Populate AppointmentType ComboBox by List<String>


        int size = 0;
        try {
            size = getDistinctAppointmentType().size();
        } catch (SQLDatabase sqlDatabase) {
            sqlDatabase.printStackTrace();
        }
        for(int i = 0; i<size; i++){
            try {
                AppointmentByTypeComboBox.getItems().add(getDistinctAppointmentType().get(i));


            } catch (SQLDatabase sqlDatabase) {
                sqlDatabase.printStackTrace();
            }
        }


        //Populate Contacts By Month
        PropertyValueFactory<Reports, String> monthContactFactory = new PropertyValueFactory<>("Month");
        PropertyValueFactory<Reports, Integer> anikaFactory = new PropertyValueFactory<>("Anika");
        PropertyValueFactory<Reports, Integer> danielFactory = new PropertyValueFactory<>("Daniel");
        PropertyValueFactory<Reports, Integer> liFactory = new PropertyValueFactory<>("Li");

        //assign cell values to Contacts By Month
        ReportsContactsMonthColumn.setCellValueFactory(monthContactFactory);
        ReportsContactAColumn.setCellValueFactory(anikaFactory);
        ReportsContactDColumn.setCellValueFactory(danielFactory);
        ReportsContactLColumn.setCellValueFactory(liFactory);


        setReportsScheduleTable();

        try {
            setReportsContactsByMonthTable();
        } catch (Exception ex) {
            Logger.getLogger(ReportController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }


    /** Method to get distinct appointment type
     *
     * @return distinct appointment type list
     * @throws SQLDatabase sql
     */
    public List<String> getDistinctAppointmentType() throws SQLDatabase {
        List<String> appointmentTypes = new ArrayList<>();

        try {

            Statement statement = SQLDatabase.getConnection().createStatement();
            String query = "SELECT appointments.Type FROM  appointments;";
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()) {
                String Type = rs.getString("Type");
                appointmentTypes.add(Type);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointmentTypes.stream().distinct().collect(Collectors.toList());
    }


    /** Method to set ContactsByMonth table
     *
     * @throws SQLException sql
     */
    private void setReportsContactsByMonthTable() throws SQLException {
        ObservableList<Reports> contactsByMonthOL = FXCollections.observableArrayList();
        try {

            Statement statement = SQLDatabase.getConnection().createStatement();
            String query = "select appointments.Start,appointments.End,appointments.Contact_ID,contacts.Contact_Name from appointments,contacts where appointments.Contact_ID = contacts.Contact_ID;";
            ResultSet rs = statement.executeQuery(query);
            contactsByMonthOL.clear();

            while (rs.next()){
                String startUTC = rs.getString("Start").substring(0,19);
                System.out. println("UTC Start: "+ startUTC);
                String endUTC = rs.getString("End").substring(0,19);
                System.out. println("UTC End: "+ endUTC);
                LocalDateTime utcStartDT = LocalDateTime.parse(startUTC,datetimeDTF);
                LocalDateTime utcEndDT = LocalDateTime.parse(endUTC,datetimeDTF);

                ZonedDateTime localZoneStart = utcStartDT.atZone(utcZoneID).withZoneSameInstant(localZoneID);
                ZonedDateTime localZoneEnd = utcEndDT.atZone(utcZoneID).withZoneSameInstant(localZoneID);
                System.out.println("localZoneStart: "+ localZoneStart);
                System.out.println("localZoneEnd: "+localZoneEnd);

                String localStartDT = localZoneStart.format(datetimeDTF);
                String localEndDT = localZoneEnd.format(datetimeDTF);
                System.out.println("localStartDT: "+ localStartDT );
                System.out.println("localEndDT: "+ localEndDT);

                String monthParse = localStartDT.substring(5,7);
                int month = Integer.parseInt(monthParse);
                System.out.println("Month parsed to Int: "+ month);
                month = month-1;


                String contact = rs.getString("Contact_Name");
                if (month == 0) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[0][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[0][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[0][2]++;
                    }
                }

                if (month == 1) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[1][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[1][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[1][2]++;
                    }
                }
                if (month == 2) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[2][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[2][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[2][2]++;
                    }
                }
                if (month == 3) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[3][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[3][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[3][2]++;
                    }
                }
                if (month == 4) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[4][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[4][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[4][2]++;
                    }
                }
                if (month == 5) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[5][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[5][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[5][2]++;
                    }
                }
                if (month == 6) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[6][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[6][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[6][2]++;
                    }
                }
                if (month == 7) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[7][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[7][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[7][2]++;
                    }
                }
                if (month == 8) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[8][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[8][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[8][2]++;
                    }
                }
                if (month == 9) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[9][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[9][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[9][2]++;
                    }
                }
                if (month == 10) {
                    if (contact.equalsIgnoreCase("Anika Costa")) {
                        monthContacts[10][0]++;
                    } else if (contact.equalsIgnoreCase("Daniel Garcia")) {
                        monthContacts[10][1]++;
                    } else if (contact.equalsIgnoreCase("Li Lee")) {
                        monthContacts[10][2]++;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int i = 0; i < 12; i++) {
            int anika = monthContacts[i][0];
            int daniel = monthContacts[i][1];
            int li = monthContacts[i][2];
            contactsByMonthOL.add(new Reports(getAbbreviatedMonth(i), anika, daniel, li));

        }
        ReportsContactsByMonthTableView.setItems(contactsByMonthOL);

    }


    /**Method to convert two digit month code into abbreviated month string
     *
     */

    private String getAbbreviatedMonth(int month){
        String abbreviatedMonth = null;
        if(month == 0){
            abbreviatedMonth ="JAN";
        }
        if(month == 1){
            abbreviatedMonth ="FEB";
        }
        if(month == 2){
            abbreviatedMonth ="MAR";
        }
        if(month == 3){
            abbreviatedMonth ="APR";
        }
        if(month == 4){
            abbreviatedMonth ="MAY";
        }
        if(month == 5){
            abbreviatedMonth ="JUN";
        }
        if(month == 6){
            abbreviatedMonth ="JUL";
        }
        if(month == 7){
            abbreviatedMonth ="AUG";
        }
        if(month == 8){
            abbreviatedMonth ="SEP";
        }
        if(month == 9){
            abbreviatedMonth ="OCT";
        }
        if(month == 10){
            abbreviatedMonth ="NOV";
        }
        if(month == 11){
            abbreviatedMonth ="DEC";
        }
        return abbreviatedMonth;
    }




    /** Method to take action when button is pressed.
     *
     * @param actionEvent action
     * @throws IOException IO
     */
    @FXML
    public void ReportsMainMenuButtonHandler(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }


    /**Method to set Reports Schedule Table
     *
     */
    private void setReportsScheduleTable() {

        ReportsScheduleTableView.setItems(AppointmentDB.getAllAppointment());

    }


    /** Method to take action when button is pressed.
     *
     * @param actionEvent action
     * @throws IOException  io
     */

    public void CheckCountsHandler(ActionEvent actionEvent) throws SQLException {

    int count = 0;
    String selectedMonth=AppointmentByMonthComboBox.getValue();
    String selectedType = AppointmentByTypeComboBox.getValue();
        if(selectedMonth!=null&&selectedType!=null){
        count =  AppointmentDB.getCount(selectedMonth,selectedType);
        numberTextField.setText(String.valueOf(count));}

        else{
            System.out.println("Please select a value from boxes ");
        numberTextField.setText(String.valueOf(0));
    }}
}
