package View_Controller;

import Database.Alerts;
import Model.*;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;


public class ViewAppointmentsController implements Initializable {

    @FXML
    TableView<Appointment> AppointmentTableView;
    @FXML
    TableColumn<Appointment, Integer> appointmentIDColumn;
    @FXML
    TableColumn<Appointment, String> appointmentContactColumn;
    @FXML
    TableColumn<Appointment, String> appointmentStartColumn;
    @FXML
    TableColumn<Appointment, String> appointmentEndColumn;
    @FXML
    TableColumn<Appointment, String> appointmentLocationColumn;
    @FXML
    TableColumn<Appointment, String> appointmentTypeColumn;
    @FXML
    TableColumn<Appointment, String> appointmentTitleColumn;
    @FXML
    TableColumn<Appointment, String> appointmentDescriptionColumn;
    @FXML
    TableColumn<Appointment, Integer> customerIDColumn;
    @FXML
    TableColumn<Appointment, Integer> userIDColumn;
    @FXML
    RadioButton AppointmentWeekRadioButton;
    @FXML
    RadioButton AppointmentMonthRadioButton;
    @FXML
    RadioButton AppointmentAllRadioButton;


    private final DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static Appointment selectedAppointment = new Appointment();

    Parent root;
    Stage stage;




    /**Method to initialize table
     *
     * @param url url
     * @param resourceBundle rs
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        PropertyValueFactory<Appointment,Integer>appointmentIDFactory = new PropertyValueFactory<>("appointmentID");
        PropertyValueFactory<Appointment,Integer>customerIDFactory = new PropertyValueFactory<>("customerID");
        PropertyValueFactory<Appointment,Integer>userIDFactory = new PropertyValueFactory<>("userID");
        PropertyValueFactory<Appointment,String>appointmentDescriptionFactory = new PropertyValueFactory<>("appointmentDescription");
        PropertyValueFactory<Appointment,String>appointmentTypeFactory = new PropertyValueFactory<>("appointmentType");
        PropertyValueFactory<Appointment,String>appointmentTitleFactory = new PropertyValueFactory<>("appointmentTitle");
        PropertyValueFactory<Appointment,String>appointmentLocationFactory = new PropertyValueFactory<>("appointmentLocation");
        PropertyValueFactory<Appointment,String>appointmentContactFactory = new PropertyValueFactory<>("appointmentContact");
        PropertyValueFactory<Appointment,String>appointmentEndFactory = new PropertyValueFactory<>("appointmentEnd");
        PropertyValueFactory<Appointment,String>appointmentStartFactory = new PropertyValueFactory<>("appointmentStart");


        appointmentIDColumn.setCellValueFactory(appointmentIDFactory);
        appointmentTitleColumn.setCellValueFactory(appointmentTitleFactory);
        appointmentDescriptionColumn.setCellValueFactory(appointmentDescriptionFactory);
        appointmentLocationColumn.setCellValueFactory(appointmentLocationFactory);
        appointmentTypeColumn.setCellValueFactory(appointmentTypeFactory );
        appointmentStartColumn.setCellValueFactory(appointmentStartFactory);
        appointmentEndColumn.setCellValueFactory(appointmentEndFactory);
        customerIDColumn.setCellValueFactory(customerIDFactory);
        userIDColumn.setCellValueFactory(userIDFactory);
        appointmentContactColumn.setCellValueFactory(appointmentContactFactory);
        ToggleGroup radioButtonToggleGroup = new ToggleGroup();
        AppointmentMonthRadioButton.setToggleGroup(radioButtonToggleGroup);
        AppointmentWeekRadioButton.setToggleGroup(radioButtonToggleGroup);
        AppointmentAllRadioButton.setToggleGroup(radioButtonToggleGroup);
        AppointmentWeekRadioButton.setSelected(false);
        AppointmentMonthRadioButton.setSelected(false);
        AppointmentAllRadioButton.setSelected(true);
        AppointmentTableView.setItems(AppointmentDB.getAllAppointment());


    }




    /** Method to take action when updatedAppointmentButton is pressed.
     *
     * @param actionEvent
     * @throws IOException
     */
    public void UpdateAppointmentButtonHandler(ActionEvent actionEvent) throws  IOException{
            selectedAppointment = AppointmentTableView.getSelectionModel().getSelectedItem();

            if ( selectedAppointment == null) {
                Alerts.infoDialog("No Selection", "Please select a customer and an appointment to edit", "You have to choose a customer to add an appointment. ");
            } else {


                Parent root = FXMLLoader.load(getClass().getResource("EditAppointment.fxml"));
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        }


    /** Method to get selected appointment
     *
     * @return selected Appointment
     */
    public  static Appointment getUpdateAppointment(){

        return  selectedAppointment;
    }


    /** Method to delete selected appointment.
     *
     * @param actionEvent action
     * @throws Exception ex
     */
    public void DeleteAppointmentButtonHandler(ActionEvent actionEvent) throws NoSuchElementException {

        selectedAppointment = AppointmentTableView.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null) {

            Alerts.infoDialog("No Selection", "Please select an appointment", "An appointment must be selected for deletion ");
        } else {
            int  appID = selectedAppointment.getAppointmentID();
            String appType = selectedAppointment.getAppointmentType();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Please confirm action");
            alert.setHeaderText("Are you sure you want to delete this customer ?");
            Optional<ButtonType> result= alert.showAndWait();
            if (result.get()== ButtonType.OK){
                Alerts.infoDialog("Information","Cancelled Appointment Details","You have cancelled an appointment with AppointmentID: "+appID+"\n"+"Appointment Type is: "+appType);
                AppointmentDB.deleteAppointment(appID);
                AppointmentTableView.setItems(AppointmentDB.getAllAppointment());

            }
            else{System.out.println("Delete cancelled");}
        }
    }


    /** Method to change view to add new appointment window .
     *
     * @param actionEvent action
     * @throws Exception ex
     */
    public void AddNewAppointmentButtonHandler(ActionEvent actionEvent) throws IOException{

        Parent root = FXMLLoader.load(getClass().getResource("AddAppointment.fxml"));
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }





    /**Method to change table view by RadioButton selected.
     *
     * @param actionEvent action
     * @throws SQLException sql
     * @throws Exception exception
     */
    public void AppointmentWeekRadioButtonHandler(ActionEvent actionEvent) throws SQLException, Exception {
        filterAppointmentByWeek(AppointmentDB.getAllAppointment());

    }

    /**Method to change table view by RadioButton selected.
     *
     * @param actionEvent action
     * @throws SQLException sql
     * @throws Exception excption
     */
    public void AppointmentAllRadioButtonHandler(ActionEvent actionEvent) throws Exception{
        AppointmentTableView.setItems(AppointmentDB.getAllAppointment());

    }

    /**Method to change table view by RadioButton selected.
     *
     * @param actionEvent action
     * @throws SQLException sql
     * @throws Exception exception
     */
    public void AppointmentMonthRadioButtonHandler(ActionEvent actionEvent) throws Exception{
        filterAppointmentByMonth(AppointmentDB.getAllAppointment());
    }



    /** Method to change view to MainScreen  window .
     *
     * @param actionEvent action
     * @throws Exception io
     */
    public void AppointmentsBackButtonHandler(ActionEvent actionEvent) throws IOException{

        root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }


    /** Method to filter ALL appointment By week
     *<p><b>
     * lambda expression used to efficiently filter appointments in next 7days from database.
     *</b></p>
     * @param appointmentsOL all appointments
     */

    public void filterAppointmentByWeek(ObservableList<Appointment> appointmentsOL) {

        LocalDate now = LocalDate.now();
        LocalDate nowPlus1Week = LocalDate.now().plusDays(7);
        FilteredList<Appointment> filteredData = new FilteredList<>(appointmentsOL);
        filteredData.setPredicate(row ->{
            LocalDate rowDate = LocalDate.parse(row.getAppointmentStart(),datetimeDTF);
            return rowDate.isAfter(now.minusDays(1) )&& rowDate.isBefore(nowPlus1Week);

        });
        AppointmentTableView.setItems(filteredData);

    }

    /** Method to filter ALL appointment By Month
     *<p><b>
     * lambda expression used to efficiently filter appointments in next 7days from database.
     *</b></p>
     * @param appointmentsOL all appointments
     */
    public void  filterAppointmentByMonth(ObservableList<Appointment>appointmentsOL) {

        LocalDate now = LocalDate.now();
        LocalDate nowPlus1Month = LocalDate.now().plusMonths(1);
        FilteredList<Appointment> filteredData = new FilteredList<>(appointmentsOL);
        filteredData.setPredicate(row ->{
            LocalDate rowDate = LocalDate.parse(row.getAppointmentStart(),datetimeDTF);
            return rowDate.isAfter(now.minusDays(1) )&& rowDate.isBefore(nowPlus1Month);

        });
        AppointmentTableView.setItems(filteredData);

    }



}










