package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**SQLDatabase Class get connected and disconnected with datebase. */

public class SQLDatabase extends Throwable {


    //Connection String
    //Server name: 3.227.166.251
    //Database name:  WJ08FfG
    //Username:  U08FfG
    //Password:  53689271638
    // JDBC driver name and database URL

    private static final String url = "jdbc:mysql://wgudb.ucertify.com:3306/WJ08FfG";
    private static final String userName="U08FfG";
    private static final String password = "53689271638";
    private  static final  String driver = "com.mysql.cj.jdbc.Driver";
    private static Connection conn;

    /**Default constructor
     *
     */
    public SQLDatabase(){}

    /** connect method to connect with database
     *
     */
    public static  void connect(){
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, userName, password);
            System.out.println("Connected to MySQL Database");

        } catch (ClassNotFoundException e) {
            System.out.println("Class Not Found" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println ("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
        }
    }

    /**Disconnect method to close Database connection. */


    public static void disconnect(){
        try{
            conn.close();
            System.out.println("Disconnected from MySQL Database");

        } catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());}
    }


    /** Return to database
     *
     * @return connection
     */
    public static Connection getConnection(){
        return conn;
    }

}