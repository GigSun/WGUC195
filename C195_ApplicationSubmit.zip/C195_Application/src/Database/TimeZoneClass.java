package Database;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class TimeZoneClass {

    /**
     * Constructor
     */
    public TimeZoneClass(){}


    /** getTimeZone Class to return timezone Label
     *
     * @return timezone lable
     */
    public static String getTimeZone(){

        Date dt = new Date();
        Calendar cal = new GregorianCalendar();
        cal.setTime(dt);
        return cal.getTimeZone().getID();
    }


    /** getTimeStamp method to return UTC time
     *
     * @return utc times
     */
    public  static  Timestamp getTimeStamp(){
        ZoneId zoneId = ZoneId.of("UTC");
        LocalDateTime localDateTime = LocalDateTime.now(zoneId);
        return Timestamp.valueOf(localDateTime);
    }




    }






