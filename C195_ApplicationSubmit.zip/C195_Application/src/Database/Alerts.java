package Database;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import java.util.Optional;

/**Alerts Class provide information about the class
 *
 */

public class Alerts{


    /** confirm function to return boolean value.
     *  return false if OK button is not selected.
     * @param title of the confirmDialog
     * @param content  of the confirmDialog
     * @return true if OK button is selected. Otherwise return false
     */

    public static boolean confirmDialog (String title, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setResizable(true);
        alert.setHeaderText("Confirm");
        alert.setContentText(content);
        Optional<ButtonType> result = alert.showAndWait();
        if(result.get()== ButtonType.OK){
            return  true;
        }
        else {
            return  false;
        }
    }

    /** infoDialog function to get infoDialog message
     *
     * @param title tile
     * @param header header
     * @param content content
     */

    public static void infoDialog(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setResizable(true);
        alert.getDialogPane().setMinHeight(250);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }



    /** Error Dialog function to get infoDialog message
     *
     * @param title
     * @param header
     * @param content
     */
    public static void errorDialog(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setResizable(true);
        alert.getDialogPane().setMinHeight(250);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

