import Database.SQLDatabase;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.SQLException;


/**
 * Main class to start application.
 */
public class Main extends Application {

    /**
     * Method to start application
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public  void start (Stage primaryStage) throws Exception{
        Parent root  =  FXMLLoader.load(getClass().getResource("View_Controller/Login.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Desktop System- Login");
        primaryStage.setScene(scene);
        primaryStage.show();





    }


    public static void main (String[] args)throws SQLException{

        SQLDatabase.connect();
        launch(args);
        SQLDatabase.disconnect();

    }


    }


